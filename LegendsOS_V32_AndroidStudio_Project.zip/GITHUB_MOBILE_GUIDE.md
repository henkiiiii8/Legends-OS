# Build and download the APK from a phone (GitHub website)

You do **not** need a computer, Android Studio or the GitHub app. Everything is done in your phone's
browser at github.com. (Labels below follow GitHub's current documentation; if a menu looks different on
your phone, switch the browser to **Desktop site** and the same names apply.)

A phone cannot upload folders, so the easiest route is: upload the project **ZIP as-is**, plus one small
workflow file. The workflow unpacks the ZIP on GitHub's servers and builds it.

## Part 1 — Create the repository
1. Sign in at github.com. Tap your profile/menu, then **New repository** (or go to github.com/new).
2. Name it e.g. `legends-os`. Tick **Add a README file** (this creates the `main` branch). Tap **Create repository**.

## Part 2 — Upload the project ZIP
1. On the repository page tap **Add file** > **Upload files**.
2. Tap **choose your files** and select `LegendsOS_V32_AndroidStudio_Project.zip` from your phone.
   Leave it zipped; do not extract it.
3. Scroll down, keep **Commit directly to the main branch**, tap **Commit changes**.

## Part 3 — Add the workflow file (one file, typed into the browser)
1. **Add file** > **Create new file**.
2. In the name box type exactly: `.github/workflows/build-apk.yml`
   (typing each `/` creates the folders).
3. Open `build-apk.yml` (provided next to the ZIP, also inside the ZIP under `.github/workflows/`),
   copy all of its text, and paste it into the editor.
4. Tap **Commit changes...** > **Commit changes**.

Committing to `main` starts a build automatically.

## Part 4 — Watch the build
1. Open the **Actions** tab. Tap the newest run of **Build LEGENDS OS APK**.
2. Wait for the green check (usually 3–6 minutes; the first run is the slowest).
3. A red X means it failed: open the run, open the failed step, and send me the error text.

To build again later: **Actions** > **Build LEGENDS OS APK** > **Run workflow** > pick `main` > **Run workflow**.

## Part 5 — Download the APK (two ways)
**Easiest: Releases (a plain .apk, no unzipping)**
1. Go to `https://github.com/<your-username>/legends-os/releases` (or the **Releases** link on the repo page).
2. Open the newest **LEGENDS OS V32 debug build** and tap `LegendsOS-V32-debug.apk`.

**Alternative: Artifacts**
1. Open the finished run in **Actions**, scroll to **Artifacts**, tap `LegendsOS-V32-debug-APK`.
2. That downloads a `.zip`; extract it with your Files app to get the `.apk`.

## Part 6 — Install and set as Home
1. Open the downloaded `.apk`. If Android asks, allow your browser/Files app to **Install unknown apps**.
   Play Protect may warn because it is a debug build; choose to install anyway.
2. Open **Settings > Apps > Default apps > Home app** (names vary by phone) and choose **LEGENDS OS HOME**.
   Or press the Home button and pick LEGENDS OS HOME when asked.
3. To go back to your old launcher: tap **Default home** in LEGENDS OS and choose the old one.

## If you have a computer instead
Extract the ZIP and drag all the **contents** (including the `.github` folder) onto
**Add file > Upload files**. The same workflow detects the extracted files and builds them.
