# LEGENDS OS V32 — Android home-screen replacement

A complete Android Studio project. It bundles the original **Highway Legends V32** game and the
LEGENDS OS launcher UI (`app/src/main/assets/index.html`, unchanged) inside a WebView and registers
the app as an Android **Home** app.

| Item | Value |
|---|---|
| Package | `com.legendsos.launcher` |
| App name | LEGENDS OS HOME |
| minSdk / targetSdk / compileSdk | 24 / 34 / 35 |
| Build tools | AGP 8.7.3, Gradle 8.9, JDK 17 |
| Permissions | none (fully offline) |

## What the native part does
- `MainActivity` has `MAIN` + `HOME` + `DEFAULT` intent filters, so it appears in
  **Settings > Apps > Default apps > Home app** and answers the Home button.
- **Phone apps** button: lists all installed launchable apps (with icons) and starts the one you tap.
- **Default home** button: opens Android's Home-app settings so you can switch back to your old launcher.
- Back button: closes a dialog, then returns from the game to the launcher screen. On the launcher
  screen it does nothing (like any home app).
- Home button while the game is open: returns to the launcher screen.
- Game saves use WebView `localStorage` (DOM storage is enabled).

## Build with Android Studio
1. **File > Open** and pick this folder. Let Gradle sync (it downloads Gradle 8.9 from
   `gradle/wrapper/gradle-wrapper.properties`).
2. **Run** on a device/emulator, or **Build > Build APK(s)**. Output:
   `app/build/outputs/apk/debug/app-debug.apk`.

> The Gradle wrapper *jar* and `gradlew` scripts are not included (they are binary and this ZIP is kept
> tiny). Android Studio does not need them. For the command line, run `gradle wrapper` once
> (with Gradle 8.9 installed) to generate them.

## Build with GitHub Actions
`.github/workflows/build-apk.yml` builds `app-debug.apk` and publishes it two ways:
a workflow **artifact** and a **GitHub Release** asset (direct `.apk` download).
Step-by-step phone instructions: see [GITHUB_MOBILE_GUIDE.md](GITHUB_MOBILE_GUIDE.md).

## Notes
- It is a Home replacement only after you choose it in Android settings. It does not replace the
  lock screen, notification shade or system settings. To revert, pick your old launcher again.
- The debug APK is signed with the standard Android debug key. Not for Play Store release.
- `targetSdk 34` is intentional: Android 15's forced edge-to-edge (targetSdk 35) would put the
  launcher's top bar under the status bar.
- The HTML title says "V34" (launcher shell label) while the embedded game is Highway Legends **V32**.
  Both are kept exactly as supplied.
