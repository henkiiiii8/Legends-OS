package com.legendsos.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * LEGENDS OS HOME: hosts the bundled launcher UI + Highway Legends V32 (assets/index.html)
 * and registers as an Android HOME app (see AndroidManifest.xml).
 */
public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/index.html";

    private WebView web;

    /** Native functions the HTML calls through window.LegendsPhone. */
    private final class PhoneBridge {
        @JavascriptInterface
        public void showApps() {
            runOnUiThread(() -> openApps());
        }

        @JavascriptInterface
        public void showHomeSettings() {
            runOnUiThread(() -> openHomeSettings());
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        web = new WebView(this);
        web.setBackgroundColor(0xff02091a);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // game saves use localStorage
        s.setAllowFileAccess(true);            // needed for file:///android_asset
        s.setDefaultTextEncodingName("UTF-8");
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new PhoneBridge(), "LegendsPhone");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) {
                    return false;
                }
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null || "file".equals(scheme) || "about".equals(scheme)
                        || "data".equals(scheme) || "blob".equals(scheme)
                        || "javascript".equals(scheme)) {
                    return false;
                }
                // Anything on the web opens in the user's browser, never inside the launcher.
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    // no browser installed
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl(START_URL);
    }

    /** Pressing the Home button while we are already the Home app returns to the launcher screen. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME)) {
            evalJs("if(typeof closeModal==='function')closeModal();"
                    + "if(typeof setGame==='function')setGame(false);");
        }
    }

    /** Back closes a dialog, then leaves the game; on the launcher screen it does nothing (like a real home app). */
    @Override
    public void onBackPressed() {
        evalJs("(function(){"
                + "var m=document.getElementById('modalOverlay');"
                + "if(m&&m.classList.contains('show')){closeModal();return;}"
                + "if(typeof gameOpen!=='undefined'&&gameOpen){setGame(false);}"
                + "})()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void evalJs(String js) {
        if (web != null) {
            web.evaluateJavascript(js, null);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openHomeSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                // nothing else we can open
            }
        }
    }

    /** Shows every installed launchable app (with icon) and starts the one the user taps. */
    private void openApps() {
        final PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);

        final List<ResolveInfo> apps = new ArrayList<>(pm.queryIntentActivities(query, 0));
        Collections.sort(apps, (a, b) ->
                a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));

        ArrayAdapter<ResolveInfo> adapter = new ArrayAdapter<ResolveInfo>(this, 0, apps) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout row;
                ImageView icon;
                TextView label;
                if (convertView == null) {
                    row = new LinearLayout(getContext());
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(16), dp(6), dp(16), dp(6));
                    icon = new ImageView(getContext());
                    icon.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                    label = new TextView(getContext());
                    label.setTextSize(16);
                    label.setTextColor(0xffffffff);
                    label.setPadding(dp(14), 0, 0, 0);
                    row.addView(icon);
                    row.addView(label);
                    row.setTag(new View[] {icon, label});
                } else {
                    row = (LinearLayout) convertView;
                }
                View[] views = (View[]) row.getTag();
                ResolveInfo info = apps.get(position);
                ((ImageView) views[0]).setImageDrawable(info.loadIcon(pm));
                ((TextView) views[1]).setText(info.loadLabel(pm));
                return row;
            }
        };

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Phone apps")
                .setAdapter(adapter, (dialog, which) -> launchApp(apps.get(which)))
                .setNegativeButton("Close", null)
                .show();
    }

    private void launchApp(ResolveInfo info) {
        Intent launch = new Intent(Intent.ACTION_MAIN);
        launch.addCategory(Intent.CATEGORY_LAUNCHER);
        launch.setComponent(new ComponentName(info.activityInfo.packageName, info.activityInfo.name));
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show();
        }
    }
}
